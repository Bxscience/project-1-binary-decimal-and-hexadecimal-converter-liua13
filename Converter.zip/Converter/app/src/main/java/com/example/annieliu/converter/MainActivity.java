package com.example.annieliu.converter;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText decimal;
    private EditText binary;
    private EditText hex;
    private Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        decimal = (EditText) findViewById(R.id.decimal);
        binary = (EditText) findViewById(R.id.binary);
        hex = (EditText) findViewById(R.id.hexadecimal);
        submit = (Button) findViewById(R.id.submit);

        decimal.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                binary.setText("");
                hex.setText("");
            }
        });

        binary.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                decimal.setText("");
                hex.setText("");
            }
        });

        hex.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                decimal.setText("");
                binary.setText("");
            }
        });

        submit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String decimalText = decimal.getText().toString();
                String binaryText = binary.getText().toString();
                String hexText = hex.getText().toString();

                String error = "";
                if(decimalText.length()!=0){
                    if(!decimalText.matches("[0-9]+")){
                        Toast.makeText(MainActivity.this, "Please enter valid a decimal value", Toast.LENGTH_LONG).show();
                        return;
                    }
                    String bTemp = decimalToBinary(decimalText);
                    binary.setText(bTemp);
                    hex.setText(binaryToHex(bTemp));
                } else if(binaryText.length()!=0){
                    if(!binaryText.matches("[0-1]+")){
                        Toast.makeText(MainActivity.this, "Please enter a valid binary value", Toast.LENGTH_LONG).show();
                        return;
                    }
                    String hTemp = binaryToHex(binaryText);
                    hex.setText(hTemp);
                    decimal.setText(hexToDecimal(hTemp));
                }else if(hexText.length()!=0) {
                    if(!hexText.matches("[a-fA-F0-9]+")){
                        Toast.makeText(MainActivity.this, "Please enter a valid hexadecimal value", Toast.LENGTH_LONG).show();
                        return;
                    }
                    String dTemp = hexToDecimal(hexText);
                    decimal.setText(dTemp);
                    binary.setText(decimalToBinary(dTemp));
                } else{
                    Toast toast = Toast.makeText(MainActivity.this, "Please enter a value.", Toast.LENGTH_LONG);
                    toast.show();
                }
            }

        });
    }

    public String backwards(String nums){
        String newNum = "";
        for(int i = nums.length()-1; i >= 0; i--){
            newNum += nums.charAt(i);
        }
        return newNum;
    }

    public String normalize(String texts){
        int zeros = 4 -(texts.length()%4);
        for(int i = 0; i < zeros; i++){
            texts += "0";
        }
        return texts;
    }

    public String decimalToBinary(String texts){
        int decimalText = Integer.parseInt(texts);
        String binaryText = "";
        while(decimalText > 0){
            if(decimalText%2==1 || decimalText==1){
                binaryText += "1";
            }else{
                binaryText += "0";
            }
            decimalText/=2;
        }
        return backwards(binaryText);
    }

    public String binaryToHex(String texts){
        String binaryBack = normalize(backwards(texts));
        String valueBack = "";

        for(int i = 0; i < binaryBack.length(); i+=4){
            int sum = 0;
            for(int j = 0; j < 4; j++){
                int power = (int) Math.pow(2, j%4);
                sum += (Integer.parseInt(String.valueOf(binaryBack.charAt(i+j)))*power);
            }
            Log.d(MainActivity.class.getSimpleName(), String.valueOf(sum));
            if(sum >= 10){
                valueBack += String.valueOf((char)(sum + 55));
            } else{
                valueBack += String.valueOf(sum);
            }
        }

        String value = backwards(valueBack);
        if(value.charAt(0)=='0'){
            return value.substring(1);
        }
        return backwards(valueBack);
    }

    public String hexToDecimal(String text){
        String texts = backwards(text.toUpperCase());
        int value = 0;

        for(int i = 0; i < texts.length(); i++){
            int x;
            if(Character.isDigit(texts.charAt(i))){
                x = Integer.parseInt(String.valueOf(texts.charAt(i)));
            }else{
                x = ((int) texts.charAt(i)) - 55;
            }
            Log.d(MainActivity.class.getSimpleName(), String.valueOf(x*Math.pow(16, i)));
            value += (x*Math.pow(16, i));
        }
        return String.valueOf(value);
    }

}
